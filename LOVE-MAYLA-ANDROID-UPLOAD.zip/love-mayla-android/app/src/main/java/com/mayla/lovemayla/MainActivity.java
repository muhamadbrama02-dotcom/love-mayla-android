package com.mayla.lovemayla;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Gravity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ColorDrawable;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.text.InputType;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private WebView web;
    private EditText passwordInput;
    private TextView message;
    private static final String URL = "https://muhamadbrama02-dotcom.github.io/love-mayla/";
    private static final String PASSWORD = "rainbowbeamw";
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(28, 9, 43));
        getWindow().setNavigationBarColor(Color.rgb(28, 9, 43));
        showPasswordScreen();
    }

    private GradientDrawable rounded(int[] colors, int radius) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, colors);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private TextView makeText(String text, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setShadowLayer(dp(3), 0, dp(1), Color.argb(210, 25, 8, 32));
        return t;
    }

    private void showPasswordScreen() {
        FrameLayout screen = new FrameLayout(this);
        ImageView background = new ImageView(this);
        background.setImageResource(com.mayla.lovemayla.R.drawable.mayla_password_bg);
        background.setScaleType(ImageView.ScaleType.CENTER_CROP);
        screen.addView(background, new FrameLayout.LayoutParams(-1, -1));

        // Very light tint only: keep Mayla's photo clearly visible.
        View shade = new View(this);
        shade.setBackground(new ColorDrawable(Color.argb(18, 22, 7, 31)));
        screen.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(28), dp(18), dp(28), dp(18));
        root.setBackgroundColor(Color.TRANSPARENT);
        screen.addView(root, new FrameLayout.LayoutParams(-1, -1));

        TextView eyebrow = makeText("♡  A LITTLE SURPRISE  ♡", 13, Color.WHITE, true);
        LinearLayout.LayoutParams eyeParams = new LinearLayout.LayoutParams(-1, -2);
        eyeParams.bottomMargin = dp(10);
        root.addView(eyebrow, eyeParams);

        TextView title = makeText("Hai, Mayla 💗", 28, Color.WHITE, true);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, -2);
        titleParams.bottomMargin = dp(5);
        root.addView(title, titleParams);

        TextView subtitle = makeText("Ada sesuatu buat kamu.", 16, Color.WHITE, false);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
        subParams.bottomMargin = dp(22);
        root.addView(subtitle, subParams);

        passwordInput = new EditText(this);
        passwordInput.setSingleLine(true);
        passwordInput.setTextColor(Color.rgb(45, 20, 55));
        passwordInput.setHintTextColor(Color.rgb(135, 112, 143));
        passwordInput.setHint("♡ Masukkan password");
        passwordInput.setTextSize(16);
        passwordInput.setPadding(dp(18), dp(12), dp(18), dp(12));
        passwordInput.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_GO);
        passwordInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        passwordInput.setBackground(rounded(new int[]{Color.WHITE, Color.rgb(250, 242, 255)}, 20));
        root.addView(passwordInput, new LinearLayout.LayoutParams(-1, dp(56)));

        Button unlock = new Button(this);
        unlock.setText("Buka 💗");
        unlock.setTextSize(16);
        unlock.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        unlock.setTextColor(Color.WHITE);
        unlock.setAllCaps(false);
        unlock.setElevation(dp(3));
        unlock.setBackground(rounded(new int[]{Color.rgb(225, 70, 164), Color.rgb(145, 55, 194)}, 20));
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(-1, dp(54));
        btnParams.topMargin = dp(12);
        root.addView(unlock, btnParams);

        message = makeText("", 13, Color.WHITE, true);
        LinearLayout.LayoutParams msgParams = new LinearLayout.LayoutParams(-1, -2);
        msgParams.topMargin = dp(10);
        root.addView(message, msgParams);

        TextView footer = makeText("made with love ♡", 12, Color.WHITE, false);
        LinearLayout.LayoutParams footParams = new LinearLayout.LayoutParams(-1, -2);
        footParams.topMargin = dp(18);
        root.addView(footer, footParams);

        unlock.setOnClickListener(v -> checkPassword());
        passwordInput.setOnEditorActionListener((v, actionId, event) -> { checkPassword(); return true; });
        setContentView(screen);
    }

    private void checkPassword() {
        String entered = passwordInput.getText().toString();
        if (PASSWORD.equals(entered)) {
            openWebsite();
        } else {
            message.setText("Belum cocok 🙈 Coba lagi, ya.");
            passwordInput.setText("");
            passwordInput.requestFocus();
        }
    }

    private void openWebsite() {
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(5,2,9));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setLoadsImagesAutomatically(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return false; }
        });
        setContentView(web);
        web.loadUrl(URL);
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
