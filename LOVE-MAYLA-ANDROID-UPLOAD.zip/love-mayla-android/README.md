# LOVE.MAYLA Android wrapper

This project packages the current LOVE.MAYLA GitHub Pages site as an Android app.

The app intentionally loads the live site:
https://muhamadbrama02-dotcom.github.io/love-mayla/

That means the V37 website files are not replaced or modified by this project. The Library also contains the V37 final ZIP as a separate backup.

## Build

Requires Android SDK + Gradle 9.5.0 and JDK 17+.

Run:

    gradle :app:assembleDebug

APK output:

    app/build/outputs/apk/debug/app-debug.apk
